#include "Engine.hpp"

int main() {
    Engine engine;

    if (!engine.init("Simple engine",800,500,false,60)) {
        return -1;
    }

    engine.setClearColor(sf::Color(50,50,50));
    engine.enableMouse(true);
    engine.enableKeyboard(true);

    engine.mainLoop();

    return 0;
}